package design_patterns_example.observer;

public interface Player {
	public void display();

	public void update(String themename, int point);
}
